import React, { useState } from "react";

const mockUsers = [
  { username: "azeez", name: "Azeez S.", shift: "Morning - ERP" },
  { username: "ibrahim", name: "Ibrahim M.", shift: "Night - Exit Gate" },
  { username: "rahamon", name: "Rahamon O.", shift: "Off Duty" },
];

function App() {
  const [user, setUser] = useState(null);
  const [input, setInput] = useState("");

  const handleLogin = () => {
    if (input === "admin") {
      setUser({ admin: true });
    } else {
      const found = mockUsers.find((u) => u.username === input);
      if (found) setUser(found);
      else alert("User not found");
    }
  };

  if (!user)
    return (
      <div>
        <h1>Login</h1>
        <input value={input} onChange={(e) => setInput(e.target.value)} />
        <button onClick={handleLogin}>Login</button>
      </div>
    );

  if (user.admin) return <h2>Welcome Admin</h2>;

  return (
    <div>
      <h2>Welcome {user.name}</h2>
      <p>Your Shift: {user.shift}</p>
    </div>
  );
}

export default App;